package pt.ulisboa.tecnico.socialsoftware.tutor.question.domain;

public enum Languages {
    Java,
    Javascript,
    Python,
    CSharp
}
