declare module 'vue-codemirror';
