export default abstract class StatementQuestionDetails {
  type!: string;

  constructor(type: string) {
    this.type = type;
  }
}
