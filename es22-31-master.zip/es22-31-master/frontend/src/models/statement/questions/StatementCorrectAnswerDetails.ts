export default abstract class StatementCorrectAnswerDetails {
  type!: string;

  constructor(type: string) {
    this.type = type;
  }
}
